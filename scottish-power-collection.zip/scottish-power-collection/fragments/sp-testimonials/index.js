/* JavaScript for sp-testimonials */
