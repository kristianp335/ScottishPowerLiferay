/* JavaScript for sp-footer */
