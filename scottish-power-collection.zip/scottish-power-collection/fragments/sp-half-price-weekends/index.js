/* JavaScript for sp-half-price-weekends */
