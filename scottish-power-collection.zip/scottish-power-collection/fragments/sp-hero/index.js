/* JavaScript for sp-hero */
