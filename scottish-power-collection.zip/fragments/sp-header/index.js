/* JavaScript for sp-header */
