/* JavaScript for sp-support-sections */
