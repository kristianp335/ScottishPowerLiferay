/* JavaScript for sp-product-cards */
